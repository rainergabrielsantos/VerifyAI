import { useState } from 'react';
import { Link2, Upload, Search, Image } from 'lucide-react';

export function HeroSection() {
  const [activeTab, setActiveTab] = useState<'url' | 'image'>('url');
  const [urlInput, setUrlInput] = useState('');
  const [dragActive, setDragActive] = useState(false);

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
  };

  const handleAnalyze = () => {
    console.log('Analyzing:', activeTab === 'url' ? urlInput : 'Image upload');
  };

  return (
    <div className="relative overflow-hidden">
      {/* Background gradient */}
      <div className="absolute inset-0 bg-gradient-to-b from-[#1A2347]/50 to-transparent pointer-events-none" />

      <div className="relative max-w-4xl mx-auto text-center space-y-8 py-16">
        {/* Headline */}
        <div className="space-y-4">
          <h1 className="text-5xl md:text-6xl text-white tracking-tight">
            Regain Clarity in <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#2D5BFF] to-[#10B981]">Today's Media</span>
          </h1>
          <p className="text-lg text-[#94A3B8] max-w-2xl mx-auto leading-relaxed">
            Instantly fact-check articles and detect AI-altered images using advanced AI. No manual research required.
          </p>
        </div>

        {/* Input Component */}
        <div className="bg-[#141B3A]/80 backdrop-blur-lg border border-white/10 rounded-2xl p-2 shadow-2xl shadow-black/20">
          {/* Tabs */}
          <div className="flex gap-2 mb-4">
            <button
              onClick={() => setActiveTab('url')}
              className={`flex-1 flex items-center justify-center gap-2 px-4 py-3 rounded-xl transition-all ${
                activeTab === 'url'
                  ? 'bg-[#2D5BFF] text-white shadow-lg shadow-[#2D5BFF]/30'
                  : 'text-[#94A3B8] hover:text-white hover:bg-white/5'
              }`}
            >
              <Link2 className="w-4 h-4" />
              Paste Web URL
            </button>
            <button
              onClick={() => setActiveTab('image')}
              className={`flex-1 flex items-center justify-center gap-2 px-4 py-3 rounded-xl transition-all ${
                activeTab === 'image'
                  ? 'bg-[#2D5BFF] text-white shadow-lg shadow-[#2D5BFF]/30'
                  : 'text-[#94A3B8] hover:text-white hover:bg-white/5'
              }`}
            >
              <Image className="w-4 h-4" />
              Upload Image
            </button>
          </div>

          {/* Input Area */}
          {activeTab === 'url' ? (
            <div className="space-y-4 p-4">
              <div className="relative">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#94A3B8]" />
                <input
                  type="text"
                  value={urlInput}
                  onChange={(e) => setUrlInput(e.target.value)}
                  placeholder="Enter URL or paste article text..."
                  className="w-full pl-12 pr-4 py-4 bg-[#0A0E27] border border-white/10 rounded-xl text-white placeholder:text-[#475569] focus:outline-none focus:border-[#2D5BFF] transition-colors"
                />
              </div>
              <button
                onClick={handleAnalyze}
                className="w-full py-4 bg-gradient-to-r from-[#2D5BFF] to-[#1E4AD9] text-white rounded-xl hover:shadow-lg hover:shadow-[#2D5BFF]/30 transition-all flex items-center justify-center gap-2"
              >
                <Search className="w-5 h-5" />
                Analyze Now
              </button>
            </div>
          ) : (
            <div className="p-4">
              <div
                onDragEnter={handleDrag}
                onDragLeave={handleDrag}
                onDragOver={handleDrag}
                onDrop={handleDrop}
                className={`border-2 border-dashed rounded-xl p-12 transition-all ${
                  dragActive
                    ? 'border-[#2D5BFF] bg-[#2D5BFF]/10'
                    : 'border-white/10 bg-[#0A0E27]/50'
                }`}
              >
                <div className="flex flex-col items-center gap-4 text-center">
                  <div className="w-16 h-16 rounded-full bg-[#2D5BFF]/20 flex items-center justify-center">
                    <Upload className="w-8 h-8 text-[#2D5BFF]" />
                  </div>
                  <div>
                    <p className="text-white mb-1">Drop your image here, or browse</p>
                    <p className="text-sm text-[#94A3B8]">Supports: JPG, PNG, WebP, GIF</p>
                  </div>
                  <button className="px-6 py-3 bg-[#2D5BFF] text-white rounded-lg hover:bg-[#2D5BFF]/90 transition-colors">
                    Choose File
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
