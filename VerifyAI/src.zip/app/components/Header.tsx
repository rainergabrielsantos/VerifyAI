import { Shield, Chrome } from 'lucide-react';
import { Link, useLocation } from 'react-router';

export function Header() {
  const location = useLocation();

  const isActive = (path: string) => {
    return location.pathname === path;
  };

  return (
    <header className="border-b border-white/10 bg-[#0A0E27] sticky top-0 z-50 backdrop-blur-lg bg-[#0A0E27]/95">
      <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
        <Link to="/" className="flex items-center gap-3 hover:opacity-80 transition-opacity">
          <div className="w-10 h-10 rounded-lg bg-[#2D5BFF] flex items-center justify-center shadow-lg shadow-[#2D5BFF]/30">
            <Shield className="w-6 h-6 text-white" />
          </div>
          <span className="text-xl text-white tracking-tight">VerifyAI</span>
        </Link>

        <nav className="hidden md:flex items-center gap-8 text-sm">
          <Link
            to="/"
            className={`transition-colors ${
              isActive('/')
                ? 'text-[#2D5BFF]'
                : 'text-[#94A3B8] hover:text-white'
            }`}
          >
            Dashboard
          </Link>
          <Link
            to="/submit"
            className={`transition-colors ${
              isActive('/submit')
                ? 'text-[#2D5BFF]'
                : 'text-[#94A3B8] hover:text-white'
            }`}
          >
            Submit Media
          </Link>
          <Link
            to="/archive"
            className={`transition-colors ${
              isActive('/archive')
                ? 'text-[#2D5BFF]'
                : 'text-[#94A3B8] hover:text-white'
            }`}
          >
            Debunk Archive
          </Link>
        </nav>

        <button className="hidden md:flex items-center gap-2 px-5 py-2.5 bg-gradient-to-r from-[#2D5BFF] to-[#1E4AD9] text-white rounded-lg text-sm hover:shadow-lg hover:shadow-[#2D5BFF]/30 transition-all">
          <Chrome className="w-4 h-4" />
          Add Extension - Free
        </button>
      </div>
    </header>
  );
}
