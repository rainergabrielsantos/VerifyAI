import { HeroSection } from '../components/HeroSection';
import { TrendingClaims } from '../components/TrendingClaims';
import { DebunkedHighlights } from '../components/DebunkedHighlights';
import { ImpactTracker } from '../components/ImpactTracker';
import { AnalysisResultPreview } from '../components/AnalysisResultPreview';
import { FloatingExtensionCTA } from '../components/FloatingExtensionCTA';
import { BreakingDebunks } from '../components/BreakingDebunks';
import { LiveClaimsFeed } from '../components/LiveClaimsFeed';
import { CategoryTabs } from '../components/CategoryTabs';
import { FeaturedClaimOfDay } from '../components/FeaturedClaimOfDay';
import { QuickAnalyzeBar } from '../components/QuickAnalyzeBar';
import { NewsTickerBanner } from '../components/NewsTickerBanner';
import { RealTimeCounter } from '../components/RealTimeCounter';

export function DashboardPage() {
  return (
    <>
      {/* Breaking News Ticker */}
      <div className="-mx-6 -mt-8 mb-0">
        <NewsTickerBanner />
      </div>

      {/* Real-time Stats Counter */}
      <div className="-mx-6 mb-6">
        <RealTimeCounter />
      </div>

      {/* Quick Analyze Sticky Bar */}
      <div className="mb-8">
        <QuickAnalyzeBar />
      </div>

      <div className="space-y-12 pb-16">
        {/* Featured Claim of the Day - Hero Replacement */}
        <FeaturedClaimOfDay />

        {/* Breaking/Urgent Debunks Section */}
        <BreakingDebunks />

        {/* Category Navigation */}
        <CategoryTabs />

        {/* Main Claims Feed - The Star of the Show */}
        <LiveClaimsFeed />

        {/* Debunked Highlights Wall - Enhanced */}
        <DebunkedHighlights />

        {/* Impact Tracker Statistics */}
        <ImpactTracker />
      </div>

      {/* Floating Extension CTA */}
      <FloatingExtensionCTA />
    </>
  );
}